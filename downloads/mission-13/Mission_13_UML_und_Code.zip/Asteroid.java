public class Asteroid {
    private double x;
    private double y;
    private double radius;
    private double vx;
    private double vy;

    public Asteroid(double x, double y, double radius, double vx, double vy) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.vx = vx;
        this.vy = vy;
    }

    public void bewege() {
        x = x + vx;
        y = y + vy;
        if (x < -radius) x = 820 + radius;
        if (x > 820 + radius) x = -radius;
        if (y < -radius) y = 620 + radius;
        if (y > 620 + radius) y = -radius;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getRadius() { return radius; }
}
