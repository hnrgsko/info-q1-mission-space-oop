import java.util.ArrayList;

public class MissionSpace {
    private Raumschiff schiff;
    private SpaceWindow window;
    private Asteroid[] asteroiden;
    private ArrayList<Planet> planeten;

    public MissionSpace() {
        Pilot pilot = new Pilot("Mina Okafor", "NOVA-7");
        schiff = new Raumschiff("Orion", 200, 300, 100);
        schiff.setPilot(pilot);

        asteroiden = new Asteroid[4];
        asteroiden[0] = new Asteroid(120, 100, 18, 0.5, 0.2);
        asteroiden[1] = new Asteroid(300, 180, 25, -0.4, 0.3);
        asteroiden[2] = new Asteroid(520, 340, 20, 0.2, -0.5);
        asteroiden[3] = new Asteroid(680, 460, 28, -0.3, -0.2);

        planeten = new ArrayList<>();
        planeten.add(new Planet("Aurelia", 670, 110, 36));
        planeten.add(new Planet("Kepler-X", 120, 500, 44));
        planeten.add(new Planet("Nova Prime", 680, 500, 30));

        window = new SpaceWindow(800, 600, "Mission Space");
    }

    public void starte() {
        while (window.isOpen()) {
            steuereRaumschiff();
            aktualisiereAsteroiden();
            tankeInPlanetennaehe();
            zeichneSzene();
            window.pause(20);
        }
    }

    private void steuereRaumschiff() {
        double schritt = window.leerzeichenGedrueckt() ? 8 : 4;
        if (window.linksGedrueckt())  schiff.fliege(-schritt, 0);
        if (window.rechtsGedrueckt()) schiff.fliege( schritt, 0);
        if (window.obenGedrueckt())   schiff.fliege(0, -schritt);
        if (window.untenGedrueckt())  schiff.fliege(0,  schritt);
    }

    private void aktualisiereAsteroiden() {
        for (Asteroid a : asteroiden) {
            a.bewege();
        }
    }

    private void tankeInPlanetennaehe() {
        if (!window.rGedrueckt()) return;
        for (Planet p : planeten) {
            if (schiff.berechneEntfernung(p.getX(), p.getY()) < p.getRadius() + 55) {
                schiff.tanke(0.5);
            }
        }
    }

    private void zeichneSzene() {
        window.beginFrame();
        for (Planet p : planeten) {
            window.drawPlanet(p.getX(), p.getY(), p.getRadius(), p.getName());
        }
        for (Asteroid a : asteroiden) {
            window.drawAsteroid(a.getX(), a.getY(), a.getRadius());
        }
        window.drawShip(schiff.getX(), schiff.getY(), schiff.getName(), schiff.getTreibstoff());
        window.drawText(20, 25, "Pfeiltasten = fliegen | Leertaste = Turbo | R = nahe Planet auftanken");
        window.drawText(20, 48, "Pilot: " + schiff.getPilot().getRufzeichen());

        Planet naechster = findeNaechstenPlaneten();
        if (naechster != null) {
            double distanz = schiff.berechneEntfernung(naechster.getX(), naechster.getY());
            window.drawText(20, 71, "Naechster Planet: " + naechster.getName()
                    + " | Distanz: " + String.format("%.0f", distanz));
        }
        window.endFrame();
    }

    public Planet findeNaechstenPlaneten() {
        Planet naechster = null;
        double kleinsteDistanz = Double.MAX_VALUE;
        for (Planet p : planeten) {
            double distanz = schiff.berechneEntfernung(p.getX(), p.getY());
            if (distanz < kleinsteDistanz) {
                kleinsteDistanz = distanz;
                naechster = p;
            }
        }
        return naechster;
    }

    public static void main(String[] args) {
        new MissionSpace().starte();
    }
}
