public class MissionSpace {
    private Raumschiff schiff;
    private SpaceWindow window;
    private Asteroid[] asteroiden;

    public MissionSpace() {
        Pilot pilot = new Pilot("Mina Okafor", "NOVA-7");
        schiff = new Raumschiff("Orion", 200, 300, 100);
        schiff.setPilot(pilot);
        window = new SpaceWindow(800, 600, "Mission Space");

        asteroiden = new Asteroid[4];
        asteroiden[0] = new Asteroid(120, 100, 18);
        asteroiden[1] = new Asteroid(300, 180, 25);
        asteroiden[2] = new Asteroid(520, 340, 20);
        asteroiden[3] = new Asteroid(680, 460, 28);
    }

    public void starte() {
        while (window.isOpen()) {
            steuereRaumschiff();
            zeichneSzene();
            window.pause(20);
        }
    }

    private void steuereRaumschiff() {
        double schritt = 4;
        if (window.linksGedrueckt())  schiff.fliege(-schritt, 0);
        if (window.rechtsGedrueckt()) schiff.fliege( schritt, 0);
        if (window.obenGedrueckt())   schiff.fliege(0, -schritt);
        if (window.untenGedrueckt())  schiff.fliege(0,  schritt);
    }

    private void zeichneSzene() {
        window.beginFrame();
        for (Asteroid a : asteroiden) {
            window.drawAsteroid(a.getX(), a.getY(), a.getRadius());
        }
        window.drawShip(schiff.getX(), schiff.getY(), schiff.getName(), schiff.getTreibstoff());
        window.drawText(20, 25, "Pilot: " + schiff.getPilot().getRufzeichen());
        window.endFrame();
    }

    public static void main(String[] args) {
        new MissionSpace().starte();
    }
}
