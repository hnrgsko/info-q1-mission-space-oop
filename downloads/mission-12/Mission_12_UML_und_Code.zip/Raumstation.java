public class Raumstation {
    private String name;
    private double x;
    private double y;
    private double reichweite;

    public Raumstation(String name, double x, double y, double reichweite) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.reichweite = reichweite;
    }

    public boolean istInReichweite(Raumschiff schiff) {
        return schiff.berechneEntfernung(x, y) <= reichweite;
    }

    public String getName() { return name; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getReichweite() { return reichweite; }
}
