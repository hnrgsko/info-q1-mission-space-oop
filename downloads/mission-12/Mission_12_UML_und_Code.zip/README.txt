MISSION 12 – Mission Design

Diese Dateien gehören zur „Lösung zum Nachvollziehen“.

So gehst du vor:
1. Entpacke die ZIP-Datei vollständig.
2. Lass alle Dateien zusammen in einem Ordner.
3. Öffne im Java-Editor zuerst „Mission_12_Loesung.uml“.
4. Vergleiche das UML-Diagramm Schritt für Schritt mit deiner eigenen Lösung.
5. Wenn du wissen möchtest, was der Java-Editor daraus im Quellcode gemacht hat, öffne die zugehörige .java-Datei.

Nutze diese Lösung vor allem zum Vergleichen deines eigenen Entwurfs: Passt dein UML-Modell zu den Anforderungen und zum Java-Code?

Die Lösung soll dir helfen, deinen eigenen Weg nachzuvollziehen. Versuche deshalb zuerst selbst weiterzukommen und nutze sie dann gezielt zum Vergleichen.

In diesem Download sind bewusst keine kompilierten Dateien enthalten.
