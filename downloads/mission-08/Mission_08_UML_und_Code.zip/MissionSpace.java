public class MissionSpace {
    private Raumschiff schiff;
    private SpaceWindow window;

    public MissionSpace() {
        schiff = new Raumschiff("Orion", 200, 300, 100);
        window = new SpaceWindow(800, 600, "Mission Space");
    }

    public void starte() {
        while (window.isOpen()) {
            steuereRaumschiff();
            zeichneSzene();
            window.pause(20);
        }
    }

    private void steuereRaumschiff() {
        double schritt = 4;
        if (window.linksGedrueckt())  schiff.fliege(-schritt, 0);
        if (window.rechtsGedrueckt()) schiff.fliege( schritt, 0);
        if (window.obenGedrueckt())   schiff.fliege(0, -schritt);
        if (window.untenGedrueckt())  schiff.fliege(0,  schritt);
    }

    private void zeichneSzene() {
        window.beginFrame();
        window.drawShip(schiff.getX(), schiff.getY(), schiff.getName(), schiff.getTreibstoff());
        window.drawText(20, 25, "Pfeiltasten = fliegen");
        window.endFrame();
    }

    public static void main(String[] args) {
        MissionSpace mission = new MissionSpace();
        mission.starte();
    }
}
