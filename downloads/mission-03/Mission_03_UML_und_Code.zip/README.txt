MISSION 03 – Konstruktoren

Diese Dateien gehören zur Lösung zum Nachvollziehen.

So gehst du vor:
1. Entpacke die ZIP-Datei vollständig in einen eigenen Ordner.
2. Lass alle Dateien gemeinsam in diesem Ordner.
3. Öffne im Java-Editor zuerst „Mission_03_Loesung.uml“.
4. Vergleiche das UML-Diagramm mit deiner eigenen Lösung.
5. Öffne anschließend bei Bedarf die zugehörigen Java-Dateien, um die Umsetzung nachzuvollziehen.

Die Lösung ist zum Vergleichen und Nachvollziehen gedacht. Versuche die Mission zuerst selbst zu lösen.

In diesem Download sind bewusst keine kompilierten .class-Dateien enthalten.
