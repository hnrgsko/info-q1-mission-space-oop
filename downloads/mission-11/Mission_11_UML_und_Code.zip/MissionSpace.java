import java.util.ArrayList;

public class MissionSpace {
    private Raumschiff schiff;
    private SpaceWindow window;
    private Asteroid[] asteroiden;
    private ArrayList<Planet> planeten;

    public MissionSpace() {
        Pilot pilot = new Pilot("Mina Okafor", "NOVA-7");
        schiff = new Raumschiff("Orion", 200, 300, 100);
        schiff.setPilot(pilot);

        asteroiden = new Asteroid[4];
        asteroiden[0] = new Asteroid(120, 100, 18);
        asteroiden[1] = new Asteroid(300, 180, 25);
        asteroiden[2] = new Asteroid(520, 340, 20);
        asteroiden[3] = new Asteroid(680, 460, 28);

        planeten = new ArrayList<>();
        planeten.add(new Planet("Aurelia", 670, 110, 36));
        planeten.add(new Planet("Kepler-X", 120, 500, 44));
        planeten.add(new Planet("Nova Prime", 680, 500, 30));

        window = new SpaceWindow(800, 600, "Mission Space");
    }

    public void starte() {
        while (window.isOpen()) {
            steuereRaumschiff();
            zeichneSzene();
            window.pause(20);
        }
    }

    private void steuereRaumschiff() {
        double schritt = 4;
        if (window.linksGedrueckt())  schiff.fliege(-schritt, 0);
        if (window.rechtsGedrueckt()) schiff.fliege( schritt, 0);
        if (window.obenGedrueckt())   schiff.fliege(0, -schritt);
        if (window.untenGedrueckt())  schiff.fliege(0,  schritt);
    }

    private void zeichneSzene() {
        window.beginFrame();
        for (Planet p : planeten) {
            window.drawPlanet(p.getX(), p.getY(), p.getRadius(), p.getName());
        }
        for (Asteroid a : asteroiden) {
            window.drawAsteroid(a.getX(), a.getY(), a.getRadius());
        }
        window.drawShip(schiff.getX(), schiff.getY(), schiff.getName(), schiff.getTreibstoff());
        window.drawText(20, 25, "Pilot: " + schiff.getPilot().getRufzeichen());

        Planet naechster = findeNaechstenPlaneten();
        if (naechster != null) {
            window.drawText(20, 48, "Naechster Planet: " + naechster.getName());
        }
        window.endFrame();
    }

    public Planet findeNaechstenPlaneten() {
        Planet naechster = null;
        double kleinsteDistanz = Double.MAX_VALUE;
        for (Planet p : planeten) {
            double distanz = schiff.berechneEntfernung(p.getX(), p.getY());
            if (distanz < kleinsteDistanz) {
                kleinsteDistanz = distanz;
                naechster = p;
            }
        }
        return naechster;
    }

    public static void main(String[] args) {
        new MissionSpace().starte();
    }
}
